<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$menus = rbac_menus('admin');
$task_route = rbac_route_key();

foreach ($menus['parents'] as $menu) {
    $children = isset($menus['children'][$menu->id]) ? $menus['children'][$menu->id] : [];
    $menu_key = strtolower(trim($menu->route_key ?: $menu->url, '/'));
    $parts = explode('/', $menu->url);
    $cls = ($this->uri->segment(2) == ($parts[1] ?? '')) ? 'active' : '';

    if (empty($children)) {
?>
<li>
    <a class="<?= $cls ?>" href="<?= base_url($menu->url) ?>">
        <i class="<?= $menu->img ?>"></i>
        <span><?= html_escape($menu->name) ?></span>
    </a>
</li>
<?php
    } else {
?>
<li class="sub-menu">
    <a href="javascript:;" class="<?= $cls ?>">
        <i class="<?= $menu->img ?>"></i>
        <span><?= html_escape($menu->name) ?></span>
    </a>
    <ul class="sub">
        <?php foreach ($children as $child_menu) {
            $cparts = explode('/', $child_menu->url);
            $ccls = ($this->uri->segment(3) == ($cparts[2] ?? '')) ? 'active' : '';
        ?>
        <li class="<?= $ccls ?>"><a href="<?= base_url($child_menu->url) ?>"><?= html_escape($child_menu->name) ?></a></li>
        <?php } ?>
    </ul>
</li>
<?php
    }
}
